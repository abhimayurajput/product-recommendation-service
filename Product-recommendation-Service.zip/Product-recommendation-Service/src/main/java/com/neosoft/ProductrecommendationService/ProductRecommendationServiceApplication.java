package com.neosoft.ProductrecommendationService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductRecommendationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductRecommendationServiceApplication.class, args);
	}

}
