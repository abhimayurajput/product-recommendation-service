package com.neosoft.ProductrecommendationService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductRecommendationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
